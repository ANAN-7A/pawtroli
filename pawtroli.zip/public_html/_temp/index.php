<?php

//Silahkan hapus file default.php dari folder public_html sebelum Anda mengupload file website Anda
// include_once dirname(__FILE__) . '/default.php';

?>

<h1>pawtroli</h1>