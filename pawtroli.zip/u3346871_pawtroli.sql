-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 20, 2021 at 03:12 PM
-- Server version: 10.3.30-MariaDB-cll-lve
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u3346871_pawtroli`
--

-- --------------------------------------------------------

--
-- Table structure for table `adopsi`
--

CREATE TABLE `adopsi` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `pemilik` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `jenis_kelamin` varchar(255) NOT NULL,
  `jenis_hewan` varchar(255) NOT NULL,
  `ras_hewan` varchar(255) NOT NULL,
  `umur` int(11) NOT NULL,
  `telepon` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `is_active` varchar(1) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adopsi`
--

INSERT INTO `adopsi` (`id`, `nama`, `pemilik`, `foto`, `jenis_kelamin`, `jenis_hewan`, `ras_hewan`, `umur`, `telepon`, `alamat`, `is_active`, `created_at`, `updated_at`) VALUES
(2, 'Denis', 'Alan Nabiel', 'artikel1.png', 'Jantan', 'Anjing', 'Bulldog', 2, '09835437245', 'Jakarta Selatan', '1', '2021-01-22 21:14:25', '2021-01-22 21:14:25'),
(5, 'Rose', 'beth', 'artikel2.png', 'Betina', 'Anjing', 'Golden Retriever', 4, '9867824515', 'Jakarta Timur', '1', '2021-01-22 09:36:50', '2021-01-22 16:44:39'),
(10, 'Momo', 'John Doe', 'artikel3.png', 'Betina', 'Anjing', 'Labrador', 3, '081232426135', 'Jakarta Pusat', '0', '2021-01-22 17:01:51', '2021-01-22 17:05:32'),
(17, 'Dan', 'Alan', '1611794531_7242bf2e938bf88f1e87.jpeg', 'Jantan', 'Kucing', 'American Shorthair', 1, '081232426135', 'Jakarta Utara', '0', '2021-01-27 18:42:11', '2021-01-28 07:47:24'),
(28, 'Rocky', 'Alan', '1614481784_1325bf4053f6fdca63b8.png', 'Betina', 'Anjing', 'Poodle', 1, '081643388234', 'RT.3/RW.1, Kembangan Utara, Kec. Kembangan, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11610', '1', '2021-02-27 21:09:44', '2021-02-27 21:09:44');

-- --------------------------------------------------------

--
-- Table structure for table `artikel`
--

CREATE TABLE `artikel` (
  `id` int(11) UNSIGNED NOT NULL,
  `judul` varchar(255) NOT NULL,
  `penulis` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `sumber_foto` varchar(255) NOT NULL,
  `teks` text DEFAULT NULL,
  `referensi` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `artikel`
--

INSERT INTO `artikel` (`id`, `judul`, `penulis`, `foto`, `sumber_foto`, `teks`, `referensi`, `created_at`, `updated_at`) VALUES
(1, 'Cara mengetahui apakah hewan peliharaan anda bosan.', 'Admin', 'artikel1.png', 'Web A', 'Tahukah anda?, bahwa binatang peliharaan itu tetap bisa merasakan kebosanan layaknya manusia </br>', 'pawtroli data faker', '1986-12-12 08:37:59', '2020-12-15 01:46:32'),
(2, 'Apakah yang dipikirkan si hewan', 'Admin', 'artikel2.png', 'Web B', 'I tell you!\' said Alice. \'Well, I shan\'t go, at any rate,\' said Alice: \'three inches is such a. <br/><br/>\r\n\r\nI tell you!\' said Alice. \'Well, I shan\'t go, at any rate,\' said Alice: \'three inches is such a.', 'pawtroli admin', '2012-04-26 00:59:00', '2020-12-15 01:46:32'),
(3, 'Bingung memilih makanan yang pas untuk hewan peliharaan', 'Admin', 'artikel3.png', 'https://rumorfix.com/home-baked-dog-treats/', 'Setiap pemilik hewan tentunya ingin memberikan yang terbaik untuk hewan peliharaannya. melakukan hal yang terbaik belum tentu yang paling tepat. banyak debat yang membahas makanan yang cocok untuk hewan peliharaan.<br/><br/>\r\n', 'pawtroli admin', '1971-11-15 01:23:51', '2020-12-15 01:46:32');

-- --------------------------------------------------------

--
-- Table structure for table `klinik`
--

CREATE TABLE `klinik` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `nama_dokter` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `koordinat` text NOT NULL,
  `deskripsi` text NOT NULL,
  `telepon` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `klinik`
--

INSERT INTO `klinik` (`id`, `nama`, `nama_dokter`, `foto`, `alamat`, `koordinat`, `deskripsi`, `telepon`, `created_at`, `updated_at`) VALUES
(6, 'Amore Animal Clinic', 'Admin Pawtroli', '1611587545_ec8d42a6363671c5bd53.png', 'Jalan Pejaten Raya No.A21, Pasar Minggu, RT.4/RW.2, Ps. Minggu, Kec. Ps. Minggu, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12510', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.890025796616!2d106.84051521530422!3d-6.278186795455969!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f2157b127add%3A0xe9950edffcb7be05!2sAMORE%20ANIMAL%20CLINIC%20-%20MMI!5e0!3m2!1sen!2sid!4v1611587205277!5m2!1sen!2sid', 'Jam operasional: 09:00 – 23:45', '0811-1042-499', '2021-01-25 09:12:25', '2021-01-25 09:12:25'),
(7, 'Animal Clinic Jakarta', 'Admin Pawtroli', '1611628045_28cc238e08e16946bab2.png', 'Jl. Warung Buncit Raya No.23, RT.2/RW.7, Pejaten Bar., Kec. Ps. Minggu, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12510', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.9120033690074!2d106.82777311545266!3d-6.275300063177794!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f226d2c3e507%3A0x9372c0437ef63c5c!2sAnimal%20Clinic%20Jakarta!5e0!3m2!1sen!2sid!4v1611627948286!5m2!1sen!2sid', 'Jam operasional: 09:30 – 18:00\r\n</br></br>\r\nANIMAL CLINIC JAKARTA merupakan klinik hewan yang didukung oleh Tenaga Medis Profesional (Dokter Hewan Praktisi) dalam mendiagnosa penyakit dan juga memiliki rasa berbelas kasih terhadap hewan kesayangan anda. Kami menggunakan alat-alat penunjang diagnosa untuk memudahkan mendeteksi penyakit dan keluhan yang ada. Sehingga pengobatan dan pencegahan yang dilakukan tepat sasaran.', '(021) 7902371', '2021-01-25 20:27:25', '2021-01-25 20:27:25'),
(8, 'Groovy Petcare Clinic', 'Admin Pawtroli', '1611628297_95416d542151ddc8ee2c.png', 'Groovy Vetcare Clinic, Jl. Radio Dalam Raya No.49, RT.3/RW.15, Gandaria Utara, Kec. Kby. Baru, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12140', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.0193809627713!2d106.78644161545257!3d-6.261177063043476!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f10b0a5d9917%3A0xb4e0594d12bdae48!2sGroovy%20Vetcare%20Clinic!5e0!3m2!1sen!2sid!4v1611628161349!5m2!1sen!2sid', 'Jam operasional: 09:00 – 12:00, 13:00 – 16:30\r\n</br></br>\r\nIn Groovy Vetcare, we understand that each Pets is special and unique with their needs and requirements. It is our responsibility to help and enable every Pawrent to keep their beloved Pets healthy and happy for life.', '(021) 72800617', '2021-01-25 20:31:37', '2021-01-25 20:31:37'),
(9, 'Animaux Pet Shop and Pet Clinic', 'Admin Pawtroli', '1611628454_8fcbfaba6d2b40c1e680.png', 'Jl. Warung Jati Barat No.40B, RT.3/RW.11, Ragunan, Kec. Ps. Minggu, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12550', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.837968025569!2d106.82384551545263!3d-6.285019263270431!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f21bd49640e5%3A0x12b86bea0a2b3b74!2sAnimaux%20Pet%20Shop%20And%20Pet%20Clinic!5e0!3m2!1sen!2sid!4v1611628392116!5m2!1sen!2sid', 'Jam operasional: 08:00 – 20:00\r\n</br></br>\r\nCat Food, Dog Food, Medicine, Vitamine, Powders, Accesoris, Dog Rewards, House Call Grooming & Doctor Visit..', '(021) 78848383', '2021-01-25 20:34:14', '2021-01-25 20:34:14'),
(10, 'Pet Vet', 'Eka Dewi Wulandari', '1611644794_57d8a5876d0547988511.jpg', 'Jl. K.H. Mas Mansyur No.8A, RT.10/RW.6, Karet Tengsin, Kecamatan Tanah Abang, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10220', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.4413250550324!2d106.81417981545205!3d-6.205370162515923!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f6a79804990b%3A0x9081b8d7050e3dc!2sPet%20Vet!5e0!3m2!1sen!2sid!4v1611644699481!5m2!1sen!2sid', 'Jam operasional: 06:00 – 22:00\r\n</br></br>\r\nPET + VET is your ultimate partner for your pawkids', '(021) 22531319', '2021-01-26 01:06:34', '2021-01-26 01:06:34'),
(11, 'Aurora Pet', 'Dewi\r\n', '1611645210_f28cd78b465bb46fd91c.jpg', 'Jl. Warung Buncit Raya No.160, RT.14/RW.2, Duren Tiga, Kec. Pancoran, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12760', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.0398541317118!2d106.82593301530406!3d-6.258480695469959!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f22d659c4111%3A0x644938fdb65dc7f3!2sAurora%20Pet!5e0!3m2!1sen!2sid!4v1611645153356!5m2!1sen!2sid', 'Jam operasional: 08:00 – 21:00\r\n</br></br>\r\nThey are not just animals to us\r\n</br>\r\nWe care about your pets as if they were ours', '0812-9016-0200', '2021-01-26 01:13:30', '2021-01-26 01:13:30'),
(12, 'Penitipan Kucing dan Praktik Dokter Hewan', 'Muhammad Fauzan', '1611645791_8699c52a48a0efb3c9d7.png', 'Jl. Gelong Baru Tengah No.20, RW.3, Tomang, Kec. Grogol petamburan, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11440', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31733.332476513344!2d106.77828263955077!3d-6.175374699999998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f72c7e37fdc3%3A0x35abf5dc56223f69!2sPenitipan%20Kucing%20%26%20Dokter%20Hewan%20Gelong!5e0!3m2!1sen!2sid!4v1611645687406!5m2!1sen!2sid', 'Jam operasional: 10:00 – 22:00', '0813-1164-5001', '2021-01-26 01:23:11', '2021-01-26 01:23:11'),
(13, 'Dokter Hewan Rezamanaf', 'Muhammad Reza \r\n', '1611646262_20d5f7bb89d93d1ba46f.png', 'Jl. Rawa Kepa Utama No.766A, Tomang, Kec. Grogol petamburan, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11440', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.7049454315816!2d106.80199449999999!3d-6.1702482000000005!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f78b49ed9893%3A0xac2af2a22738ace2!2sDOKTER%20HEWAN%20REZAMANAF!5e0!3m2!1sen!2sid!4v1611646052597!5m2!1sen!2sid', 'Jam operasional: 10:00 – 21:00', '0821-6483-6288', '2021-01-26 01:31:02', '2021-01-26 01:31:02'),
(14, 'Rumah Sakit Hewan Jakarta', 'Imelda Meiliany Priandini', '1611646573_d44f689a20e6fa330d23.jpg', 'Jl. Harsono RM No.28, RT.9/RW.4, Ragunan, Kec. Ps. Minggu, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12550', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.7305271881633!2d106.8196245840236!3d-6.299097298979843!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69edff06f9baff%3A0x8ac5766d50acdbbb!2sRagunan%20Animal%20Hospital!5e0!3m2!1sen!2sid!4v1611646388094!5m2!1sen!2sid', 'Jam operasional: 08:00 – 21:00\r\n</br></br>\r\nMelayani dengan kasih, Serve with love', '(021) 7891093', '2021-01-26 01:36:13', '2021-01-26 01:36:13');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` text NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1, '2020-12-14-055051', 'App\\Database\\Migrations\\Artikel', 'default', 'App', 1607925303, 1),
(2, '2021-01-21-052320', 'App\\Database\\Migrations\\AddConnections', 'default', 'App', 1611207069, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tempat`
--

CREATE TABLE `tempat` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `koordinat` text NOT NULL,
  `deskripsi` text NOT NULL,
  `telepon` varchar(255) NOT NULL,
  `tipe` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tempat`
--

INSERT INTO `tempat` (`id`, `nama`, `foto`, `alamat`, `koordinat`, `deskripsi`, `telepon`, `tipe`, `created_at`, `updated_at`) VALUES
(9, 'PAWSOME Pet Grooming & Salon Hewan', '1611582089_903ac44ec485ceb2e297.png', 'RT.3/RW.1, Kembangan Utara, Kec. Kembangan, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11610', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.610399379517!2d106.73122681545208!3d-6.18286736230464!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f7dc08e60c21%3A0xeb8cbb0b4903a033!2sPAWSOME%20PET%20GROOMING%20%26%20SALON%20HEWAN%20PANGGILAN%20JAKARTA%20-%20Groomer%20Anjing%20Kucing%20Termurah%20dan%20Professional!5e0!3m2!1sen!2sid!4v1611580156894!5m2!1sen!2sid', 'Jam operasional : 24 jam\r\n</br></br>\r\nKami telah memiliki pelanggan di Jakarta, Bekasi, Depok, dan Tangerang. Berpengalaman dengan berbagai tipe hewan peliharaan, customer, dan permintaan khusus.</br>\r\nPawsome memiliki 10 tenaga profesional di bidangnya dengan harga jasa mulai dari 90k (member diskon 10k). Harga murah tanpa mengurangi kualitas sedikitpun. Hanya kami yang dapat memberikan rasio kualitas dan harga 1:1\r\n</br></br>\r\nJasa kami meliputi:\r\n</br></br>\r\n1. Paket Basic Grooming= 90-120k\r\n</br>\r\n-Mandi Sehat\r\n</br>\r\n-Gunting Kuku\r\n</br>\r\n-Cukur Trimming (Paw, Belly, Butt)\r\n</br>\r\n-Blow Dry\r\n</br>\r\n-Parfum\r\n</br>\r\n-Bersihkan Telinga\r\n</br></br>\r\n2. Paket Premium Grooming= 150-200k\r\n</br>\r\n-Mandi Sehat Premium (Jamur + Kutu)\r\n</br>\r\n-Cukur Trimming + Model / Styling\r\n</br>\r\n-Gunting Kuku\r\n</br>\r\n-Blow Dry\r\n</br>\r\n-Sisir\r\n</br>\r\n-Parfum\r\n</br>\r\n-Bersihkan Telinga\r\n</br>\r\n-Pemberian Vitamin Bulu + Kalsium\r\n</br></br>\r\n*Di luar area Jakarta order minimal transaksi 300ribu. Dikarenakan kondisi lapangan dan jadwal yang dikhususkan untuk Anda\r\n</br></br></br>\r\n\r\nAdd-on Services:\r\n</br></br>\r\n-Mandi Jamur + Kutu (Ringan)= 20-30k\r\n</br>\r\n-Obat Tetes Kutu (Keras)= 80k\r\n</br>\r\n-Gunting Kuku= 20k\r\n</br>\r\n-Cukur Model / Styling= 100k\r\n</br>\r\n-Cukur botak= 75-100k\r\n</br>\r\n-Jasa sikat gigi (free sikat gigi)= 40k\r\n</br></br></br>\r\n\r\nSelain grooming, kami juga melayani supply barang kebutuhan hewan peliharaan anda, silahkan hubungi kami untuk informasi lebih lanjut dan pemesanan jadwal grooming (H-3 dikarenakan jadwal yang padat agar tidak mengurangi kualitas grooming)', '0818-0609-0589', 'grooming', '2021-01-25 07:41:29', '2021-01-25 07:41:29'),
(10, 'OPPI Pet Salon & Grooming', '1611582529_781f7df282b8b69817ee.png', 'Jl. Perumahan Green Garden, RT.9/RW.10, Kedoya Utara, Kec. Kb. Jeruk, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11520', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.695325212173!2d106.7516949153037!3d-6.17153339553194!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f7a4645214a9%3A0x869d85b10aa01f2c!2sOPPIPET%20SALON%20%26%20GROOMING!5e0!3m2!1sen!2sid!4v1611582467594!5m2!1sen!2sid', 'Jam operasional: 09.00 – 19.00\r\n</br></br>\r\nProfessional House Call Grooming Service\r\n</br></br>\r\nMelayani Panggilan Salon Hewan Kesayangan Kaki 4 Kita Yang Khususnya (Anjing Dan Kucing) Dengan Groomer Yang Berpengalaman dan Professional, Kami Siap Untuk Merawat Hewan Peliharaan Tersayang Kalian Yang Berada Di Wilayah Jakarta dan Bekasi.\r\n</br></br>\r\nCegah Hewan Trauma Saat Pengerjaan  Mulai Dari Sekarang Juga!!! Thankyou:)', '0897-1789-251', 'grooming', '2021-01-25 07:48:49', '2021-01-25 07:48:49'),
(11, 'Gading Pet Center', '1611582986_442efc59c2e57d55326d.png', 'Boulevard Raya LB 3 No.6 RT.12/RW.18 Kelapa Gading Timur Kelapa Gading RT.12, RT.12/RW.18, Klp. Gading Tim., Jakarta, Kota Jkt Utara, Daerah Khusus Ibukota Jakarta 14240', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.8140714666824!2d106.90605031530374!3d-6.155650995543258!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f535b5d01653%3A0x6e787343b9ca93f7!2sGading%20Pet%20Center!5e0!3m2!1sen!2sid!4v1611582892519!5m2!1sen!2sid', 'Jam operasional: 08:00 – 22:00\r\n</br></br>\r\nGading Pet Center Pet Shop yang berada di seberang MKG 3 menyediakan fasilitas lengkap seperti grooming, home grooming, penyemprotan disinfektan, pet hotel, playground dan treadmill khusus anjing trah besar. Kami juga menyediakan beberapa kebutuhan lainnya seperti makanan dan aksesoris. Tidak luput juga menyediakan jasa medis untuk checkup maupun untuk perawatan hewan jika sakit.', '(021) 4500995', 'grooming', '2021-01-25 07:56:26', '2021-01-25 07:56:26'),
(12, 'Lychee House-Call Pet Grooming', '1611583281_7a4f749d7505caccbc7c.png', 'Jl. Brawijaya VIII, RT.1/RW.3, Pulo, Kec. Kby. Baru, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12160', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.113793120672!2d106.80418911530417!3d-6.248733095476946!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f7bb733ca69d%3A0x57d30250a7fe32ac!2sLychee%20House-Call%20Pet%20Grooming%20(Salon%20Anjing%20Kucing%20Panggilan%20Ke%20Rumah)!5e0!3m2!1sen!2sid!4v1611583159198!5m2!1sen!2sid', 'Jam operasional: 24 jam\r\n</br></br>\r\nAvailable every day, Call us now!', '0817-6942-125', 'grooming', '2021-01-25 08:01:21', '2021-01-25 08:01:21'),
(13, 'Meeow House', '1611583459_7f597d2b549ad3366aa5.png', 'Jl. Cempaka Putih Barat XIV A No.A18, RT.7/RW.12, Cemp. Putih Bar., Kec. Cemp. Putih, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10520', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.627176347644!2d106.86382231530376!3d-6.180629995525433!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f4f8b0d2d2ef%3A0x346717aebade639!2sMeeow%20House!5e0!3m2!1sen!2sid!4v1611583371475!5m2!1sen!2sid', 'Jam operasional: 10:00 – 20:00\r\n</br></br>\r\nALL ABOUT A CATS\r\n</br></br>\r\nJasa layanan perawatan kucing peliharaan ', '0857-7870-0004', 'hotel', '2021-01-25 08:04:19', '2021-01-25 08:04:19'),
(14, 'Miru Pet Hotel & Store', '1611583714_8accb85abc73e0dcb971.png', 'Apartment Menteng Square Tower, Jl. Matraman Raya No.30E, RT.5/RW.6, Kenari, Kec. Senen, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10310', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.477454381334!2d106.84945071530387!3d-6.200568395511213!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f5b567432169%3A0x1534931f82087bd2!2sMiru%20Pet%20Hotel%20%26%20Store!5e0!3m2!1sen!2sid!4v1611583560986!5m2!1sen!2sid', 'Jam operasional: 09:00 – 18:00\r\n</br></br>\r\n CAT HOTEL - STORE - GROOMING\r\n Pick up & delivery', ' 0813-5000-7479', 'hotel', '2021-01-25 08:08:34', '2021-01-25 08:08:34'),
(15, 'B Pets', '1611583962_5e636a4a9ea490845ddc.png', 'West, RT.5/RW.3, Pegadungan, Kebon Jeruk, West Jakarta City, Jakarta 11830', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.996165335564!2d106.70586321530365!3d-6.131216195560665!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6a02a4fa6423c9%3A0xddb59bac79430c79!2sB%20Pets!5e0!3m2!1sen!2sid!4v1611583831431!5m2!1sen!2sid', 'Jam operasional: 09:30 – 20:30\r\n</br></br>', '0896-6664-1411', 'hotel', '2021-01-25 08:12:42', '2021-01-25 08:12:42'),
(16, 'Gading Pet Center', '1611582986_442efc59c2e57d55326d.png', 'Boulevard Raya LB 3 No.6 RT.12/RW.18 Kelapa Gading Timur Kelapa Gading RT.12, RT.12/RW.18, Klp. Gading Tim., Jakarta, Kota Jkt Utara, Daerah Khusus Ibukota Jakarta 14240', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.8140714666824!2d106.90605031530374!3d-6.155650995543258!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f535b5d01653%3A0x6e787343b9ca93f7!2sGading%20Pet%20Center!5e0!3m2!1sen!2sid!4v1611582892519!5m2!1sen!2sid', 'Jam operasional: 08:00 – 22:00\r\n</br></br>\r\nGading Pet Center Pet Shop yang berada di seberang MKG 3 menyediakan fasilitas lengkap seperti grooming, home grooming, penyemprotan disinfektan, pet hotel, playground dan treadmill khusus anjing trah besar. Kami juga menyediakan beberapa kebutuhan lainnya seperti makanan dan aksesoris. Tidak luput juga menyediakan jasa medis untuk checkup maupun untuk perawatan hewan jika sakit.', '(021) 4500995', 'hotel', '2021-01-25 07:56:26', '2021-01-25 07:56:26'),
(18, 'Pondok Pengayom Satwa', '1611584852_025d735bfaefe01a2545.png', 'Jl. Harsono RM No.10, RT.9/RW.4, Ragunan, Kec. Ps. Minggu, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12550', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.722297137184!2d106.81817271530436!3d-6.300174395440269!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69edff7ee7b2ff%3A0xeca8a7fe4eef3225!2sPondok%20Pengayom%20Satwa!5e0!3m2!1sen!2sid!4v1611584639801!5m2!1sen!2sid', 'Jam operasional: 09:00 – 16.00\r\n</br></br>\r\nEmail: satwapondokpengayom@yahoo.com', '(021) 7819617 / 08119378809', 'shelter', '2021-01-25 08:27:32', '2021-01-25 08:27:32'),
(19, 'Yayasan Pencinta Satwa Jakarta', '1611585655_87e7efe0878f14ba1757.png', 'Gedung Sarana Jaya, Jl. Tebet Barat IV, RT.8/RW.2, Tebet Bar., Kec. Tebet, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12810', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d126903.11465132717!2d106.75032135085732!3d-6.300169721451271!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f394288fffff%3A0xe04e8fee7f3f12f7!2sYayasan%20Pencinta%20Satwa%20Jakarta!5e0!3m2!1sen!2sid!4v1611585459224!5m2!1sen!2sid', 'Email: admin@jakartadoglovers.com\r\n</br></br>\r\nYayasan Pencinta Satwa Jakarta didirikan berdasarkan kesamaan visi dan misi dalam memasyarakatkan anjing di tengah-tengah kehidupan bermasyarakat. Dengan tujuan agar seluruh pecinta anjing, selain mengasihi dan merawat dengan baik, pemilik juga dapat memberdayakan serta memanfaatkan anjing untuk kepentingan keluarga, masyarakat dan negara.\r\n</br></br>\r\nYayasan Pencinta Satwa Jakarta diresmikan secara hukum dalam rangka memayungi komunitas-komunitas pencinta satwa yang selama ini masih sebatas perkumpulan, yang dalam menjalankan aktivitasnya masih mengandalkan kemampuan member. Yayasan Pencinta Satwa Jakarta disahkan negara melalui SK Pengesahan Kementerian Hukum dan HAM Nomor AHU-0031230.AH.01.04 tanggal 8 Agustus 2016.\r\n</br></br>\r\nBeberapa misi yang akan diemban oleh Yayasan ini adalah :\r\n</br></br>\r\n1. Melibatkan stakeholder dalam rangka mendata sebaran anjing dan kucing yang tidak terdata oleh Institusi resmi yang menangani anjing dan kucing dengan sistem chip;\r\n</br></br>\r\n2. Melibatkan stakeholder dalam rangka melakukan edukasi kepada generasi muda melalui institusi pendidikan untuk meningkatkan kesejahteraan satwa;\r\n</br></br>\r\n3. Melibatkan stakeholder dalam rangka membangun sistem pengendalian dan penanganan satwa domestik.\r\n</br></br>\r\nDengan terbentuknya Yayasan Pencinta Satwa Jakarta, semua komunitas yang terbentuk akan memberdayakan komunitas-komunitas tersebut menjadi perkumpulan resmi secara hukum melalui yayasan dan diberikan tempat dalam divisi per komunitas di jajaran pengurus.\r\n</br></br>\r\nTerbuka untuk komunitas pencinta anjing yang baru terbentuk untuk melegalkan kegiatan dan aktivitas sosialnya.', '0812-8708-0889', 'shelter', '2021-01-25 08:40:55', '2021-01-25 08:40:55'),
(23, 'Pejaten Animal Shelter', '1611818742_379caa37fcc2c79f3cd1.png', 'Jalan Pejaten Barat No. 45T, RT.2/RW.8, West Pejaten, Pasar Minggu, South Jakarta City, Jakarta 12540', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.89819985497!2d106.82338291530408!3d-6.277113295456666!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f22247474b1b%3A0xc7bda75c7bf228ef!2sPejaten%20Shelter!5e0!3m2!1sen!2sid!4v1611584333761!5m2!1sen!2sid', 'Help pet live better', '0818-872-761 / 08111022761', 'shelter', '2021-01-28 01:25:42', '2021-01-28 01:25:42');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `nama_klinik` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `foto` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `nama_klinik`, `address`, `phone`, `foto`, `email`, `password`, `role`, `created_at`, `updated_at`) VALUES
(8, 'Admin', '', 'Jakarta timur', '', '', 'admin@pawtroli.com', '$2y$10$D7o6zf6.vUiXPB9CMIP6.O.rWz/zFu2NJZGJNrTLzCcqzhjOiX19K', 'admin', '2021-01-20 20:46:00', '2021-01-20 20:46:00'),
(9, 'Alan', '', '', '', 'USER.png', 'alank401lb@gmail.com', '$2y$10$aNu5ZScJ0yy8FeGmIjaf9eF/NV8pqoB/GQYyJrrgSGQGzgxbOYWmK', 'user', '2021-01-20 20:55:07', '2021-01-27 08:17:57'),
(16, 'Eka Dewi Wulandari', 'Pet Vet', 'Jakarta Pusat', '0857-7777-2900', 'EDW.png', 'edwulandari@pawtroli.com', '$2y$10$h7wJtDjyVSULr8TxhzUJR.AH4jcO7sThJyk4SwXTdRt/UqwfXY6ye', 'dokter', '2021-01-26 11:18:36', '2021-01-25 22:26:29'),
(18, 'Dewi', 'Aurora Pet', 'Jakarta Selatan', '0812-9016-0200', 'D.png', 'dewi@pawtroli.com', '$2y$10$BX5Zs8SqHGLVkbPdZJq2g.5.bcfT27lvIcrH0i1N.tFJJxbTWwu9O', 'dokter', '2021-01-26 11:20:44', '2021-01-26 00:34:13'),
(19, 'Muhammad Fauzan', 'Penitipan Kucing dan Praktik Dokter Hewan', 'Jakarta Barat', '0823-6407-9226', 'MF.png', 'mfauzan@pawtroli.com', '$2y$10$vc1oO9jTP6BI0ICK5eGCoeIn2r0iMQafv4fzdk1FoFLAAEJ/G9wSu', 'dokter', '2021-01-26 11:22:00', '2021-01-25 22:26:33'),
(20, 'Muhammad Reza ', 'Dokter Hewan Rezamanaf', 'Jakarta Barat', '0821-6483-6288', 'MR.png', 'mreza@pawtroli.com', '$2y$10$BZbdM2k6pBGV0BOAiU77kehE6oHzbbkCClZwGSL5wkV1/tv1QTjXm', 'dokter', '2021-01-26 11:22:30', '2021-01-25 22:26:35'),
(21, 'Imelda Meiliany Priandini', 'Rumah Sakit Hewan Jakarta', 'Jakarta Selatan', '0813-4275-6556', 'IMP.png', 'impriandini@pawtroli.com', '$2y$10$YCcJqhYcrJsLJ59Lq/sLzes/E/NXECmhJ6NuENgcDnBiD1lwifSDq', 'dokter', '2021-01-26 11:23:39', '2021-01-25 22:26:37'),
(22, 'Ria Yunitianingsih', 'Smilevet Kelapa Gading Jakarta', 'Jakarta Utara', '0856-9313-9394', 'RY.png', 'ryunitianingsih@pawtroli.com', '$2y$10$lAWDeHd4mzZarn85vAaiU.H90Jnynf0dcY0/48XqBslq/0bU4.vwi', 'dokter', '2021-01-26 11:24:34', '2021-01-25 22:26:39'),
(23, 'Febriana Sardi R', 'Jakarta Vet', 'Jakarta Pusat', '081310193078', 'FSR.png', 'fsardir@pawtroli.com', '$2y$10$6WFBNSq79nlpl2mdxRAei.jpinfDXHA/A/C3aOEw/uLjAIPEHbWle', 'dokter', '2021-01-26 11:26:02', '2021-01-25 22:26:42'),
(24, 'faqih', '', NULL, NULL, '', 'faqihrex21@gmail.com', '$2y$10$weDkZWb0n7UuYzr87arLr.wp79Q/5SU7jmc.qZ5mXL.5kQTHd37nG', 'user', '2021-01-28 20:38:59', '2021-01-28 20:38:59'),
(25, 'Muhammad Ridwan', '', NULL, NULL, '', 'mridwan499@gmail.com', '$2y$10$jI1Gnxr5wdsuBiVNLrbh/eGWlI01Jk/KI7ar3GznZjvuas0yhyPHe', 'user', '2021-01-28 22:36:10', '2021-01-28 22:36:10'),
(26, 'Wahyu Retno Prihatiningsih', '', NULL, NULL, '', 'prihatiningsihwr@gmail.com', '$2y$10$NfMBEpsX4jCAV3hHuvKf9uIHzyoXuGpUU0BigsvH9uYz9qOka63A2', 'user', '2021-01-29 13:31:00', '2021-01-29 13:31:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adopsi`
--
ALTER TABLE `adopsi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `klinik`
--
ALTER TABLE `klinik`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tempat`
--
ALTER TABLE `tempat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adopsi`
--
ALTER TABLE `adopsi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `artikel`
--
ALTER TABLE `artikel`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123;

--
-- AUTO_INCREMENT for table `klinik`
--
ALTER TABLE `klinik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tempat`
--
ALTER TABLE `tempat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
