<?php

namespace App\Models;

use CodeIgniter\Model;

class TempatModel extends Model
{
    protected $table      = 'tempat';
    protected $useTimestamps = true;
    // agar bisa data bisa dimasukkan ke DB
    protected $allowedFields = ['nama', 'foto', 'alamat', 'koordinat', 'deskripsi', 'telepon', 'tipe'];

    public function search($keyword)
    {
        return $this->table('tempat')->like('nama', $keyword);
    }

    public function getTempat($nama = false)
    {
        if ($nama == false) {
            return $this->findAll();
        }

        return $this->where(['nama' => $nama])->first();
    }
}
