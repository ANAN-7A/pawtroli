<?php

namespace App\Models;

use CodeIgniter\Model;

class AdopsiModel extends Model
{
    protected $table      = 'adopsi';
    protected $useTimestamps = true;
    // agar bisa data bisa dimasukkan ke DB
    protected $allowedFields = ['nama', 'pemilik', 'foto', 'jenis_kelamin', 'jenis_hewan', 'ras_hewan', 'umur', 'telepon', 'alamat', 'is_active'];

    public function search($keyword)
    {
        return $this->table('adopsi')->like('nama', $keyword);
    }

    public function getAdopsi($nama = false)
    {
        if ($nama == false) {
            return $this->findAll();
        }

        return $this->where(['nama' => $nama])->first();
    }
}
