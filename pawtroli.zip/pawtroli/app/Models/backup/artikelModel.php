<?php

namespace App\Models;

use CodeIgniter\Model;

class ArtikelModel extends Model
{
    protected $table      = 'artikel';
    protected $useTimestamps = true;
    // agar bisa data bisa dimasukkan ke DB
    protected $allowedFields = ['judul', 'teks'];

    public function search($keyword)
    {
        // $builder = $this->table('artikel');
        // $builder->like('judul', $keyword);
        // return $builder;

        return $this->table('artikel')->like('judul', $keyword)->orLike('teks', $keyword);
    }
}
