<?php

namespace App\Models;

use CodeIgniter\Model;

class DokterModel extends Model
{
    protected $table      = 'dokter';
    protected $useTimestamps = true;
    // agar bisa data bisa dimasukkan ke DB
    protected $allowedFields = ['nama', 'slug', 'lokasi_praktek', 'foto'];

    public function search($keyword)
    {
        // $builder = $this->table('dokter');
        // $builder->like('nama', $keyword);
        // return $builder;

        return $this->table('dokter')->like('nama', $keyword);
    }

    public function getDokter($slug = false)
    {
        if ($slug == false) {
            return $this->findAll();
        }

        return $this->where(['slug' => $slug])->first();
    }
}
