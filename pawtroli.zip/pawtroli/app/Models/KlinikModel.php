<?php

namespace App\Models;

use CodeIgniter\Model;

class KlinikModel extends Model
{
    protected $table      = 'klinik';
    protected $useTimestamps = true;
    // agar bisa data bisa dimasukkan ke DB
    protected $allowedFields = ['nama', 'nama_dokter', 'foto', 'alamat', 'koordinat', 'deskripsi', 'telepon'];

    public function search($keyword)
    {
        return $this->table('klinik')->like('nama', $keyword);
    }

    public function getKlinik($nama = false)
    {
        if ($nama == false) {
            return $this->findAll();
        }

        return $this->where(['nama' => $nama])->first();
    }
}
