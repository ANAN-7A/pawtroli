<?php

namespace App\Models;

use CodeIgniter\Model;

class DokterHewanModel extends Model
{
    protected $table      = 'users';
    protected $useTimestamps = true;
    protected $allowedFields = ['role', 'nama_klinik', 'phone', 'foto', 'address'];

    public function search($keyword)
    {
        // $builder = $this->table('dokter');
        // $builder->like('nama', $keyword);
        // return $builder;

        return $this->table('users')->like('name', $keyword);
    }

    public function getDokterHewan($name = false)
    {
        if ($name == false) {
            return $this->findAll();
        }

        return $this->where(['name' => $name])->first();
    }
}
