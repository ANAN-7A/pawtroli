<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Pager extends BaseConfig
{
	/*
	|--------------------------------------------------------------------------
	| Templates
	|--------------------------------------------------------------------------
	|
	| Pagination links are rendered out using views to configure their
	| appearance. This array contains aliases and the view names to
	| use when rendering the links.
	|
	| Within each view, the Pager object will be available as $pager,
	| and the desired group as $pagerGroup;
	|
	*/
	public $templates = [
		'default_full'   => 'CodeIgniter\Pager\Views\default_full',
		'default_simple' => 'CodeIgniter\Pager\Views\default_simple',
		'default_head'   => 'CodeIgniter\Pager\Views\default_head',
		'artikel_pagination' => 'CodeIgniter\Pager\Views\artikel_pagination',
		'dokter_pagination' => 'CodeIgniter\Pager\Views\dokter_pagination',
		'tempat_pagination' => 'CodeIgniter\Pager\Views\tempat_pagination'
	];
    // pagination custom nya dipindahin ke tempat view default ci4
    // appnya -> app/vendor/codeigniter4/framework/system/pager/views

	/*
	|--------------------------------------------------------------------------
	| Items Per Page
	|--------------------------------------------------------------------------
	|
	| The default number of results shown in a single page.
	|
	*/
	public $perPage = 20;
}
