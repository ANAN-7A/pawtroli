<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>About Pawtroli</h1>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Iste voluptas perspiciatis commodi et ex id repellat aperiam! Repellendus expedita odit quo dolorum eum optio quibusdam pariatur suscipit, ratione velit accusamus.</p>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>