<?= $this->extend('templates/v_template'); ?>

<?= $this->section('content'); ?>
<!-- Page Content -->
<div class="container">

    <!-- Heading Row -->
    <div class="row align-items-center my-5">
        <div class="col-lg-7">
            <h1 class="font-weight-light" style="font-size: 3rem">Veterinarian</h1>
        </div>
        <!-- /.col-lg-8 -->
        <div class="col-lg-5">
            <div class="card text-white bg-secondary my-1 py-1 text-center">
                <div class="card-body">
                    <form action="" method="GET">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search..." name="keyword">
                            <button class="btn btn-info" type="submit" name="submit">Search</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
        <!-- /.col-md-4 -->
    </div>
    <!-- /.row -->

    <!-- Content Row -->
    <div class="row">

        <?php foreach ($dokterHewan as $dh) : ?>
            <?php if ($dh['role'] == 'dokter') : ?>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card h-100 bg-light">
                        <a href="/dokterHewan/detail/<?= $dh['name']; ?>"><img class="card-img-top" src="/img/<?= $dh['foto']; ?>" alt=""></a>
                        <div class="card-body">
                            <h3 class="card-title font-weight-light">drh. <?= $dh['name']; ?></h3>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (session()->get('role') == 'admin') : ?>
                <?php if ($dh['role'] == 'user') : ?>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card h-100 bg-light">
                        <a href="/dokterHewan/detail/<?= $dh['name']; ?>"><img class="card-img-top" src="/img/<?= $dh['foto']; ?>" alt=""></a>
                        <div class="card-body">
                            <h3 class="card-title font-weight-light"><?= $dh['name']; ?></h3>
                        </div>
                            <div class="card-footer">
                                <a href="/dokterHewan/dokterRole/<?= $dh['id']; ?>" class="btn btn-warning btn-sm">Change user role to veterinarian</a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; ?>

    </div>
    <!-- /.row -->

    <!-- ingat kalau mau bikin pagination harus ada template dan jangan lupa register ke app/config/pager.php -->
    <?= $pager->links('dokter', 'dokter_pagination'); ?>

</div>
<!-- /.container -->
<?= $this->endSection(); ?>