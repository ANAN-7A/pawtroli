<?= $this->extend('templates/v_template'); ?>

<?= $this->section('content'); ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <div class="col-lg-3">
            <h2 class="my-4">drh. <?= $dokterHewan['name']; ?></h2>
            <div class="list-group">
                <p href="#" class="card-footer"><b>Kontak:</b> </br><?= $dokterHewan['phone']; ?></p>
                <p href="#" class="card-footer"><b>Klinik di <?= $dokterHewan['address']; ?>:</b></p>
                <a href="/klinik/detail/<?= $dokterHewan['nama_klinik']; ?>" class="btn btn-info"><?= $dokterHewan['nama_klinik']; ?></a>
                <br>
                <?php if ($dokterHewan['name'] == session()->get('name')) : ?>
                    <a href="/dokterHewan/update/" class="btn btn-info">Update data</a>
                <?php endif; ?>
            </div>
        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9">

            <div class="card mt-4">
                <img class="card-img-top img-fluid" src="/img/<?= $dokterHewan['foto']; ?>" alt="">
            </div>
            <!-- /.card -->
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br>

        </div>
        <!-- /.col-lg-9 -->

    </div>

</div>
<!-- /.container -->
<?= $this->endSection(); ?>