<?= $this->extend('templates/v_template'); ?>

<?= $this->section('content'); ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <div class="col-lg-3">
            <h1 class="my-4">Free Adoption Info</h1>
            <div class="list-group">
                <p href="#" class="card-footer"><b>Kontak:</b> </br><?= $adopsi['pemilik']; ?><br><?= $adopsi['telepon']; ?></p>
                <p href="#" class="card-footer"><b>Alamat:</b> </br><?= $adopsi['alamat']; ?></p>
                <br>
                <?php if ($adopsi['pemilik'] == session()->get('name')) : ?>
                    <a href="/adopsi/nonactive/<?= $adopsi['id']; ?>" class="btn btn-info btn-sm">Deactivate Free Adoption
                    </a>
                    </br>
                    <a href="/adopsi/delete/<?= $adopsi['id']; ?>" class="btn btn-info btn-sm">Delete Free Adoption</a>
                <?php endif; ?>
            </div>
        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9">

            <div class="card mt-4">
                <img class="card-img-top img-fluid" src="/img/<?= $adopsi['foto']; ?>" alt="">
                <div class="card-body">
                    <h5 class="lead">Nama:</h5>
                    <h5 class="card-title"><?= $adopsi['nama']; ?></h5>
                    <hr>
                    <h5 class="lead">Umur:</h5>
                    <h5 class="card-title leader"><?= $adopsi['umur']; ?> Tahun</h5>
                    <hr>
                    <h5 class="lead">Jenis Kelamin:</h5>
                    <h5 class="card-title"><?= $adopsi['jenis_kelamin']; ?></h5>
                    <hr>
                    <h5 class="lead">Jenis Hewan:</h5>
                    <h5 class="card-title"><?= $adopsi['jenis_hewan']; ?></h5>
                    <hr>
                    <h5 class="lead">Ras Hewan:</h5>
                    <h5 class="card-title leader"><?= $adopsi['ras_hewan']; ?></h5>
                </div>
            </div>
            <br>
            <!-- /.card -->

        </div>
        <!-- /.col-lg-9 -->

    </div>

</div>
<!-- /.container -->
<?= $this->endSection(); ?>