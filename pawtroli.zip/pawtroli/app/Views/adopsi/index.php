<?= $this->extend('templates/v_template'); ?>

<?= $this->section('content'); ?>
<!-- Page Content -->
<div class="container">

    <!-- Heading Row -->
    <div class="row align-items-center my-5">
        <div class="col-lg-7">
            <h1 class="font-weight-light" style="font-size: 3rem">Free Adoption</h1>
        </div>
        <!-- /.col-lg-8 -->
        <div class="col-lg-5">
            <?php if (session()->get('isLoggedIn')) : ?>
                <a class="btn btn-info" href="/adopsi/create">Create Free Adoption</a>
            <?php else : ?>
            
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#exampleModal">
                  Create Free Adoption
                </button>
                
                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Login Diperlukan</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        Silahkan login terlebih dahulu sebelum upload adopsi hewan
                      </div>
                      <div class="modal-footer">
                        <a class="btn btn-info" href="/login">Login</a>
                      </div>
                    </div>
                  </div>
                </div>
            <?php endif; ?>

            <?php if (session()->get('success')) : ?>
                <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Info</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        Adopsi hewan berhasil dimasukkan
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-info" data-dismiss="modal">Tutup</button>
                      </div>
                    </div>
                  </div>
                </div>
            <?php endif; ?>
            <?php if (session()->get('pesan1')) : ?>
                <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Info</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        Adopsi hewan berhasil dinonaktifkan
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-info" data-dismiss="modal">Tutup</button>
                      </div>
                    </div>
                  </div>
                </div>
            <?php endif; ?>
            <?php if (session()->get('pesan2')) : ?>
                <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Info</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        Adopsi hewan berhasil dihapus
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-info" data-dismiss="modal">Tutup</button>
                      </div>
                    </div>
                  </div>
                </div>
            <?php endif; ?>
            <div class="card text-white bg-secondary my-1 py-1 text-center">
                <div class="card-body">
                    <form action="" method="GET">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search..." name="keyword">
                            <button class="btn btn-info" type="submit" name="submit">Search</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
        <!-- /.col-md-4 -->
    </div>
    <!-- /.row -->

    <!-- Content Row -->
    <div class="row">

        <?php foreach ($adopsi as $ad) : ?>
            <?php if ($ad['is_active'] == '1') : ?>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card h-100 bg-light">
                        <a href="/adopsi/detail/<?= $ad['nama']; ?>"><img class="card-img-top" src="/img/<?= $ad['foto']; ?>" alt=""></a>
                        <div class="card-body">
                            <h3 class="card-title font-weight-light"><?= $ad['nama']; ?></h3>
                            <p class="card-text"><?= $ad['jenis_hewan']; ?> <?= $ad['ras_hewan']; ?></p>
                            <p class="card-text">Umur: <?= $ad['umur']; ?> tahun</p>
                        </div>
                        <div class="card-footer">
                            <a href="/adopsi/detail/<?= $ad['nama']; ?>" class="btn btn-info btn-sm">Info Hewan</a>
                        </div>
                    </div>
                </div>
                <!-- /.col-md-4 -->
            <?php elseif ($ad['is_active'] == '0') : ?>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card h-100 bg-light">
                        <a href="#"><img class="card-img-top" src="/img/<?= $ad['foto']; ?>" alt=""></a>
                        <div class="card-body">
                            <h3 class="card-title font-weight-light"><?= $ad['nama']; ?></h3>
                            <p class="card-text"><?= $ad['jenis_hewan']; ?> <?= $ad['ras_hewan']; ?></p>
                            <p class="card-text">Umur: <?= $ad['umur']; ?> tahun</p>
                        </div>
                        <?php if ($ad['pemilik'] == session()->get('name')) : ?>
                            <div class="card-footer">
                                <a href="/adopsi/delete/<?= $ad['id']; ?>" class="btn btn-warning btn-sm">Delete Free Adoption</a>
                            </div>
                        <?php endif; ?>
                        <div class="card-footer">
                            <a href="#" class="btn btn-secondary btn-sm disabled">Terima kasih. hewan sudah diadopsi</a>
                        </div>
                    </div>
                </div>
                <!-- /.col-md-4 -->
            <?php endif; ?>
        <?php endforeach; ?>

    </div>
    <!-- /.row -->

    <?= $pager->links('tempat', 'tempat_pagination'); ?>

</div>
<!-- /.container -->
<?= $this->endSection(); ?>