<?= $this->extend('templates/v_template'); ?>

<?= $this->section('content'); ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <div class="col-lg-3">
            <h1 class="my-4"><?= $klinik['nama']; ?></h1>
            <div class="list-group">
                <p href="#" class="card-footer"><b>Kontak:</b> </br><?= $klinik['telepon']; ?></p>
                <p href="#" class="card-footer"><b>Alamat:</b> </br><?= $klinik['alamat']; ?></p>
                <?php if ($klinik['nama_dokter'] !== 'Admin Pawtroli') : ?>
                    <p href="/dokterHewan/detail/<?= $klinik['nama_dokter']; ?>" class="card-footer"><b>Dokter Hewan yang bekerja di klinik ini:</b></p>
                    <a href="/dokterHewan/detail/<?= $klinik['nama_dokter']; ?>" class="btn btn-info">drh. <?= $klinik['nama_dokter']; ?></a>
                <?php endif; ?>
            </div>
        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9">

            <div class="card mt-4">
                <img class="card-img-top img-fluid" src="/img/<?= $klinik['foto']; ?>" alt="">
                <div class="card-body">
                    <hr>
                    <p class="card-text"><?= $klinik['deskripsi']; ?></p>
                </div>
            </div>
            <!-- /.card -->

            <div class="card card-outline-secondary my-4">
                <div class="card-header">
                    Map
                </div>
                <div class="card-body">
                    <!-- EMBEDDED MAP HERE -->

                    <div class="container">
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe src="<?= $klinik['koordinat']; ?>" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                        </div>
                    </div>

                    <!-- EMBEDDED MAP HERE -->
                </div>
            </div>
            <!-- /.card -->

        </div>
        <!-- /.col-lg-9 -->

    </div>

</div>
<!-- /.container -->
<?= $this->endSection(); ?>