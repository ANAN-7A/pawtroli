<?= $this->extend('templates/v_template'); ?>

<?= $this->section('content'); ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <!-- Post Content Column -->
        <div class="col-lg-8">

            <!-- Title -->
            <h1 class="mt-4"><?= $artikel['judul']; ?></h1>

            <!-- Author -->
            <p class="lead">
                by
                <?= $artikel['penulis']; ?>
            </p>

            <hr>

            <!-- Date/Time -->
            <!-- <p>Posted on January 1, 2019 at 12:00 PM</p> -->
            <p>Posted on <?= $artikel['updated_at']; ?></p>

            <hr>

            <!-- Preview Image -->
            <img class="img-fluid rounded" src="/img/<?= $artikel['foto']; ?>" alt="">
            <p>
                Sumber:
                <a href="<?= $artikel['sumber_foto']; ?>"><?= $artikel['sumber_foto']; ?></a>
            </p>

            <hr>

            <!-- Post Content -->

            <p><?= $artikel['teks']; ?></p>

            <hr>

            <p class="lead">
                Reference:
                <a><?= $artikel['referensi']; ?></a>
            </p>

            <hr>
            
        </div>

    </div>
    <!-- /.row -->

</div>
<!-- /.container -->
<?= $this->endSection(); ?>