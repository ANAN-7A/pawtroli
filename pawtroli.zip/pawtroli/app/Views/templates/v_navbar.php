  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
      <div class="container">
          <a class="navbar-brand" href="/">
          <img class="img-fluid col-lg-8" style="" src="/assets/img/pawtroliTextNavbar.png">
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
              <ul class="navbar-nav ml-auto">
                  <li class="nav-item">
                      <a class="nav-link" href="/dokterHewan">Veterinarian</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="/klinik">Clinic</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="/adopsi">Free Adoption</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="/artikel">Article</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="/hotel">Pet Hotel</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="/grooming">Pet Grooming</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="/shelter">Pet Shelter</a>
                  </li>

                  <?php if (session()->get('isLoggedIn')) : ?>
                      <!-- Nav Item - User Information -->
                      <li class="nav-item dropdown no-arrow">
                          <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              <span class="mr-2 d-lg-inline">
                                  <?= session()->get('name') ?>
                              </span>
                              <img class="img-profile rounded-circle" src="/assets/img/undraw_profile.svg">
                          </a>
                          <!-- Dropdown - User Information -->
                          <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">

                              <a class="dropdown-item" href="/profile">
                                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                  Profile
                              </a>
                              <div class="dropdown-divider"></div>

                              <a class="dropdown-item" href="/logout">
                                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                  Logout
                              </a>

                          </div>
                      </li>
                  <?php else : ?>
                      <li>
                          <a href="/login">
                              <button class="btn btn-outline-secondary my-2 my-sm-0 ml-2" type="submit">Login</button>
                          </a>
                      </li>
                  <?php endif; ?>

              </ul>
          </div>
      </div>
  </nav>