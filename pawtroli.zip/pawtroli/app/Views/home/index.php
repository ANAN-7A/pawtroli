<?= $this->extend('templates/v_template'); ?>

<?= $this->section('content'); ?>
<!-- Page Content -->
<div class="container">

    <!-- Jumbotron Header -->
    <header class="jumbotron mb-0 mt-0 bg-white">
        <img class="mx-auto d-block img-fluid unlock-icon col-lg-3" style="" src="/assets/img/pawtroliTextNavbar.png" alt="">
        <p class="lead text-center">A place to All Your Pets Need</p>
    </header>
    
    <!--style="background-image: url(/assets/img/Blank.jpg");"-->

    <!-- Page Features -->
    <div class="row text-center">

        <div class="col-lg-3 col-md-6 mb-4">
            <div class="card h-100">
                <a href="/dokterHewan">
                    <img class="card-img-top" src="/assets/img/Veterinarian.jpg" alt="">
                </a>
                <div class="card-footer">

                    <p class="card-text">Konsultasi dengan dokter hewan.</p>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 mb-4">
            <div class="card h-100">
                <a href="/klinik">
                    <img class="card-img-top" src="/assets/img/Clinic.jpg" alt="">
                </a>
                <div class="card-footer">

                    <p class="card-text">Carikan klinik untuk kesehatan hewan peliharaan.</p>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 mb-4">
            <div class="card h-100">
                <a href="/adopsi">
                    <img class="card-img-top" src="/assets/img/Free Adoption.jpg" alt="">
                </a>
                <div class="card-footer">

                    <p class="card-text">Adopsi mudah dari pemilik hewan lain.</p>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 mb-4">
            <div class="card h-100">
                <a href="/artikel">
                    <img class="card-img-top" src="/assets/img/Article.jpg" alt="">
                </a>
                <div class="card-footer">

                    <p class="card-text">Informasi seputar hewan peliharaan.</p>
                </div>
            </div>
        </div>

    </div>

    <!-- Page Features 2 -->
    <div class="row text-center">

        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100">
                <a href="/hotel">
                    <img class="card-img-top" src="/assets/img/Pet Hotel.jpg" alt="">
                </a>
                <div class="card-footer">

                    <p class="card-text">Butuh penitipan hewan peliharaan? disni tempatnya.</p>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100">
                <a href="/grooming">
                    <img class="card-img-top" src="/assets/img/Pet Grooming.jpg" alt="">
                </a>
                <div class="card-footer">

                    <p class="card-text">Carilah perawatan yang tepat untuk hewan peliharaan anda.</p>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100">
                <a href="/shelter">
                    <img class="card-img-top" src="/assets/img/Pet Shelter.jpg" alt="">
                </a>
                <div class="card-footer">

                    <p class="card-text">Berikanlah rumah yang lebih baik untuk mereka dengan Pet Shelter.</p>
                </div>
            </div>
        </div>

    </div>
    <!-- /.row -->

</div>
<!-- /.container -->
<?= $this->endSection(); ?>