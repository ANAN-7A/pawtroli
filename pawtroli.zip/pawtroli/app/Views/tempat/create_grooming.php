<?= $this->extend('templates/v_template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-8">
            <h2 class="my-3">Create Pet Grooming</h2>
            <!-- validasi sudah masing-masing di form -->
            <!-- tag phpp // $validation->listErrors();  -->
            <!-- enctype ini dipake buat bekerja dengan files -->
            <form action="/grooming/create" method="POST" enctype="multipart/form-data">
                <!-- anti bajak dari csrf -->
                <?= csrf_field(); ?>
                <div class="row mb-3">
                    <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                    <div class="col-sm-10">
                        <!-- kasih logika untuk validation | ketika ada validasi error field yang sudah terisi tetap ada -->
                        <input type="text" class="form-control" id="nama" name="nama" autofocus value="<?= set_value('nama') ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
                    <div class="col-sm-10">
                        <!-- kasih logika untuk validation | ketika ada validasi error field yang sudah terisi tetap ada -->

                        <input type="text" class="form-control" id="alamat" name="alamat" value="<?= session()->get('alamat') ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="foto" class="col-sm-2 col-form-label">Gambar</label>
                    <!-- div ini dipakai untuk menampilkan preview foto -->
                    <div class="col-sm-2">
                        <img src="/img/default.jpg" class="img-thumbnail img-preview">
                    </div>
                    <div class="col-sm-8">
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="foto" name="foto" onchange="previewImg()">
                            <label class="custom-file-label" for="foto">Pilih Gambar</label>
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="koordinat" class="col-sm-2 col-form-label">Koordinat Gmaps</label>
                    <div class="col-sm-10">
                        <!-- kasih logika untuk validation | ketika ada validasi error field yang sudah terisi tetap ada -->
                        <input type="text" class="form-control" id="koordinat" name="koordinat" value="<?= set_value('koordinat') ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="deskripsi" class="col-sm-2 col-form-label">Deskripsi</label>
                    <div class="col-sm-10">
                        <!-- kasih logika untuk validation | ketika ada validasi error field yang sudah terisi tetap ada -->
                        <textarea class="form-control" id="deskripsi" name="deskripsi" value="<?= set_value('deskripsi') ?>" rows="15"></textarea>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="telepon" class="col-sm-2 col-form-label">Telepon</label>
                    <div class="col-sm-10">
                        <!-- kasih logika untuk validation | ketika ada validasi error field yang sudah terisi tetap ada -->
                        <input type="text" class="form-control" id="telepon" name="telepon" value="<?= set_value('telepon') ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-10">
                        <!-- kasih logika untuk validation | ketika ada validasi error field yang sudah terisi tetap ada -->
                        <input type="text" class="form-control" id="tipe" name="tipe" readonly hidden value="grooming">
                    </div>
                </div>
                <?php if (isset($validation)) : ?>
                    <div class="col-12">
                        <div class="alert alert-danger" role="alert">
                            <?= $validation->listErrors() ?>
                        </div>
                    </div>
                <?php endif; ?>
                <button type="submit" class="btn btn-info">Create Pet Grooming</button>
                <input type="button" class="btn btn-info float-right" value="Back" onclick="history.back()">
            </form>
            <br>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>