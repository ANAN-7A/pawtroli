c<?= $this->extend('templates/v_template'); ?>

<?= $this->section('content'); ?>
<!-- Page Content -->
<div class="container">

    <!-- Heading Row -->
    <div class="row align-items-center my-5">
        <div class="col-lg-7">
            <h1 class="font-weight-light" style="font-size: 3rem">Pet Grooming</h1>
        </div>
        <!-- /.col-lg-8 -->
        <div class="col-lg-5">
            <?php if (session()->get('role') == 'admin') : ?>
                <a class="btn btn-info" href="/grooming/create">Create Pet Grooming</a>
            <?php else : ?>
            <?php endif; ?>

            <?php if (session()->get('success')) : ?>
                <div class="alert alert-success" role="alert">
                    <?= session()->get('success') ?>
                </div>
            <?php endif; ?>
            <div class="card text-white bg-secondary my-1 py-1 text-center">
                <div class="card-body">
                    <form action="" method="GET">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search..." name="keyword">
                            <button class="btn btn-info" type="submit" name="submit">Search</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
        <!-- /.col-md-4 -->
    </div>
    <!-- /.row -->

    <!-- Content Row -->
    <div class="row">

        <?php foreach ($tempat as $t) : ?>
            <?php if ($t['tipe'] == 'grooming') : ?>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card h-100 bg-light">
                        <a href="/grooming/detail/<?= $t['nama']; ?>">
                            <img class="card-img-top" src="/img/<?= $t['foto']; ?>" alt="">
                        </a>
                        <div class="card-body">
                            <h3 class="card-title font-weight-light"><?= $t['nama']; ?></h3>
                        </div>
                        <?php if (session()->get('role') == 'admin') : ?>
                            <div class="card-footer">
                                <a href="/grooming/delete/<?= $t['id']; ?>" class="btn btn-warning btn-sm">Delete Pet Grooming</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- /.col-md-4 -->
            <?php endif; ?>
        <?php endforeach; ?>

    </div>
    <!-- /.row -->

    <?= $pager->links('tempat', 'tempat_pagination'); ?>

</div>
<!-- /.container -->
<?= $this->endSection(); ?>