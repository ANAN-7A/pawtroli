<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-8">
            <h2 class="my-3">Form Ubah Data Dokter</h2>
            <!-- validasi sudah masing-masing di form -->
            <!-- tag phpp // $validation->listErrors();  -->
            <!-- enctype ini dipake buat bekerja dengan files -->
            <form action="/dokter/update/<?= $dokter['id']; ?>" method="POST" enctype="multipart/form-data">
                <!-- anti bajak dari csrf -->
                <?= csrf_field(); ?>
                <input type="hidden" name="slug" value="<?= $dokter['slug']; ?>">
                <input type="hidden" name="fotoLama" value="<?= $dokter['foto']; ?>">
                <div class="row mb-3">
                    <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                    <div class="col-sm-10">
                        <!-- kasih logika untuk validation | ketika ada validasi error field yang sudah terisi tetap ada -->
                        <input type="text" class="form-control <?= ($validation->hasError('nama')) ? 'is-invalid' : ''; ?>" id="nama" name="nama" autofocus value="<?= (old('nama')) ? old('nama') : $dokter['nama'] ?>">
                        <div class="invalid-feedback">
                            <?= $validation->getError('nama'); ?>.
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="lokasi_praktek" class="col-sm-2 col-form-label">Lokasi Praktek</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="lokasi_praktek" name="lokasi_praktek" value="<?= (old('lokasi_praktek')) ? old('lokasi_praktek') : $dokter['lokasi_praktek'] ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="foto" class="col-sm-2 col-form-label">Foto</label>
                    <!-- div ini dipakai untuk menampilkan preview foto -->
                    <div class="col-sm-2">
                        <img src="/img/<?= $dokter['foto']; ?>" class="img-thumbnail img-preview">
                    </div>
                    <div class="col-sm-8">
                        <div class="custom-file">
                            <input type="file" class="custom-file-input <?= ($validation->hasError('foto')) ? 'is-invalid' : ''; ?>" id="foto" name="foto" onchange="previewImg()">
                            <div class="invalid-feedback">
                                <?= $validation->getError('foto'); ?>.
                            </div>
                            <label class="custom-file-label" for="foto"><?= $dokter['foto']; ?></label>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Ubah Dokter</button>
            </form>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>