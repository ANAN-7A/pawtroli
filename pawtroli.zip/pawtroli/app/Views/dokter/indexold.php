<?= $this->extend('templates/v_template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1 class="mt-2">Daftar Dokter Hewan <a href="/dokter/create" class="btn btn-primary">Tambah Data Dokter</a></h1>

            <!-- kasih message setelah insert -->
            <?php if (session()->getFlashdata('pesan')) : ?>
                <div class="alert alert-success" role="alert">
                    <?= session()->getFlashdata('pesan'); ?>
                </div>
            <?php endif ?>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Foto</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- agar id bisa ngitung dari 1 | Ditambah dengan logika penghitungan halaman -->
                    <?php $i = 1 + (4 * ($currentPage - 1)); ?>
                    <?php foreach ($dokter as $d) : ?>
                        <tr>
                            <th scope="row"><?= $i++; ?></th>
                            <td><img src="/img/<?= $d['foto']; ?>" alt="" class="foto"></td>
                            <td>Dr. <?= $d['nama']; ?></td>
                            <td>
                                <a href="/dokter/<?= $d['slug']; ?>" class="btn btn-success">Detail</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <!-- ingat kalau mau bikin pagination harus ada template dan jangan lupa register ke app/config/pager.php -->
            <?= $pager->links('dokter', 'dokter_pagination'); ?>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>