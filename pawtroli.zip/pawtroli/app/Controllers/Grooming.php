<?php

namespace App\Controllers;

use App\Models\TempatModel;

class Grooming extends BaseController
{
    protected $tempatModel;

    public function __construct()
    {
        $this->tempatModel = new TempatModel();
    }

    public function index()
    {
        // kasih logika klo ada isi berarti page ambil isinya klo gk ada page 1
        $currentPage = $this->request->getVar('page_tempat') ? $this->request->getVar('page_tempat') : 1;

        $keyword = $this->request->getVar('keyword');
        if ($keyword) {
            $tempat = $this->tempatModel->search($keyword);
        } else {
            $tempat = $this->tempatModel;
        }

        $data = [
            'title' => 'Pawtroli | Pet Grooming',
            // 'artikel' => $this->artikelModel->findAll()
            // klo jumlah paginate diubah jangan lupa diganti kalkulasi logika nya
            'tempat' => $tempat->paginate(18, 'tempat'),
            'pager' => $this->tempatModel->pager,
            'currentPage' => $currentPage
        ];

        return view('tempat/index_grooming', $data);
    }

    public function detail($nama)
    {
        $data = [
            'title' => 'Pawtroli | Pet Grooming',
            'tempat' => $this->tempatModel->getTempat($nama)
        ];

        // jika dokter tidak ditemukan
        if (empty($data['tempat'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Tempat ' . $nama . ' tidak ditemukan.');
        }

        return view('tempat/detail_grooming', $data);
    }

    public function create()
    {
        $data = [
            'title' => 'Pawtroli | Pet Grooming'
        ];
        helper(['form']);

        if ($this->request->getMethod() == 'post') {
            // validation rules
            $rules = [
                'nama' => 'required',
                'alamat' => 'required',
                'koordinat' => 'required',
                'telepon' => 'required',
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                //store user on database
                $model = new TempatModel();

                // ambil gambar
                $fileFoto = $this->request->getFile('foto');
                // apabila tidak ada gambar yang di upload | == 4 maksudnya error tidak ada file yang diupload
                if ($fileFoto->getError() == 4) {
                    $namaFoto = 'default.jpg';
                } else {
                    //generate nama foto random
                    $namaFoto = $fileFoto->getRandomName();
                    // pindahkan file ke folder img
                    $fileFoto->move('img', $namaFoto);
                }

                $newData = [
                    'nama' => $this->request->getVar('nama'),
                    'foto' => $namaFoto,
                    'alamat' => $this->request->getVar('alamat'),
                    'koordinat' => $this->request->getVar('koordinat'),
                    'deskripsi' => $this->request->getVar('deskripsi'),
                    'telepon' => $this->request->getVar('telepon'),
                    'tipe' => $this->request->getVar('tipe'),
                ];
                $model->save($newData);
                $session = session();

                $session->setFlashdata('success', 'Tambah Pet Grooming Sukses');
                return redirect()->to('/grooming');
            }
        }

        echo view('tempat/create_grooming', $data);
    }
    
    public function delete($id)
    {
        //cari gambar berdasarkan id
        $tempat = $this->tempatModel->find($id);

        // cek jika file gambarnya default
        if ($tempat['foto'] != 'default.jpg') {
            // hapus gambar
            unlink('img/' . $tempat['foto']);
        }

        $this->tempatModel->delete($id);
        session()->setFlashdata('pesan', 'Pet Grooming berhasil dihapus');
        return redirect()->to('/grooming');
    }
    
}
