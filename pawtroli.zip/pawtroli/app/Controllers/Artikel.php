<?php

namespace App\Controllers;

use App\Models\ArtikelModel;

class Artikel extends BaseController
{
    protected $artikelModel;

    public function __construct()
    {
        $this->artikelModel = new ArtikelModel();
    }

    public function index()
    {
        // kasih logika klo ada isi berarti page ambil isinya klo gk ada page 1
        $currentPage = $this->request->getVar('page_artikel') ? $this->request->getVar('page_artikel') : 1;

        $keyword = $this->request->getVar('keyword');
        if ($keyword) {
            $artikel = $this->artikelModel->search($keyword);
        } else {
            $artikel = $this->artikelModel;
        }

        $data = [
            'title' => 'Daftar Artikel',
            // 'artikel' => $this->artikelModel->findAll()
            // klo jumlah paginate diubah jangan lupa diganti kalkulasi logika nya
            'artikel' => $artikel->paginate(9, 'artikel'),
            'pager' => $this->artikelModel->pager,
            'currentPage' => $currentPage
        ];

        return view('artikel/index', $data);
    }

    public function detail($judul)
    {
        $data = [
            'title' => 'Pawtroli | Artikel',
            'artikel' => $this->artikelModel->getArtikel($judul)
        ];

        // jika dokter tidak ditemukan
        if (empty($data['artikel'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Artikel ' . $judul . ' tidak ditemukan.');
        }

        return view('artikel/detail', $data);
    }

    public function create()
    {
        $data = [
            'title' => 'Tambah Artikel'
        ];
        helper(['form']);

        if ($this->request->getMethod() == 'post') {
            // validation rules
            $rules = [
                'judul' => 'required|is_unique[artikel.judul]',
                'penulis' => 'required',
                'sumber_foto' => 'required',
                'teks' => 'required',
                'referensi' => 'required',
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                //store user on database
                $model = new ArtikelModel();

                // ambil gambar
                $fileFoto = $this->request->getFile('foto');
                // apabila tidak ada gambar yang di upload | == 4 maksudnya error tidak ada file yang diupload
                if ($fileFoto->getError() == 4) {
                    $namaFoto = 'default.jpg';
                } else {
                    //generate nama foto random
                    $namaFoto = $fileFoto->getRandomName();
                    // pindahkan file ke folder img
                    $fileFoto->move('img', $namaFoto);
                }

                $newData = [
                    'judul' => $this->request->getVar('judul'),
                    'penulis' => $this->request->getVar('penulis'),
                    'foto' => $namaFoto,
                    'sumber_foto' => $this->request->getVar('sumber_foto'),
                    'teks' => $this->request->getVar('teks'),
                    'referensi' => $this->request->getVar('referensi'),
                ];
                $model->save($newData);
                $session = session();

                $session->setFlashdata('success', 'Tambah Artikel Sukses');
                return redirect()->to('/artikel');
            }
        }

        echo view('artikel/create', $data);
    }
    
    public function delete($id)
    {
        //cari gambar berdasarkan id
        $artikel = $this->artikelModel->find($id);

        // cek jika file gambarnya default
        if ($artikel['foto'] != 'default.jpg') {
            // hapus gambar
            unlink('img/' . $artikel['foto']);
        }

        $this->artikelModel->delete($id);
        session()->setFlashdata('pesan', 'Artikel berhasil dihapus');
        return redirect()->to('/artikel');
    }
    
}
