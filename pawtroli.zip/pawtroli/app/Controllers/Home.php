<?php

namespace App\Controllers;

class Home extends BaseController
{
	public function index()
	{
		$data = [
			'title' => 'Pawtroli | Home',
		];

		return view('home/index', $data);
	}

	//--------------------------------------------------------------------

}
