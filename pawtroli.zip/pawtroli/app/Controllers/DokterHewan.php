<?php

namespace App\Controllers;

use App\Models\DokterHewanModel;

class DokterHewan extends BaseController
{
    protected $dokterHewanModel;

    public function __construct()
    {
        $this->dokterHewanModel = new DokterHewanModel();
    }

    public function index()
    {
        // kasih logika klo ada isi berarti page ambil isinya klo gk ada page 1
        $currentPage = $this->request->getVar('page_dokterHewan') ? $this->request->getVar('page_dokterHewan') : 1;

        $keyword = $this->request->getVar('keyword');
        if ($keyword) {
            $dokterHewan = $this->dokterHewanModel->search($keyword);
        } else {
            $dokterHewan = $this->dokterHewanModel;
        }

        $data = [
            'title' => 'Pawtroli | Veterinary',
            'dokterHewan' => $dokterHewan->paginate(12, 'dokterHewan'),
            'pager' => $this->dokterHewanModel->pager,
            'currentPage' => $currentPage
        ];


        return view('dokterHewan/index', $data);
    }

    public function detail($name)
    {
        $data = [
            'title' => 'Pawtroli | Veterinary',
            'dokterHewan' => $this->dokterHewanModel->getDokterHewan($name)
        ];

        // jika dokter tidak ditemukan
        if (empty($data['dokterHewan'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Dokter ' . $name . ' tidak ditemukan.');
        }

        return view('dokterHewan/detail', $data);
    }

    public function dokterRole($id)
    {
        //cari gambar berdasarkan nama
        $dokterHewan = $this->dokterHewanModel->find($id);

        $this->dokterHewanModel->save([
            'id' => $id,
            'role' => 'dokter'
        ]);
        session()->setFlashdata('pesan', 'User berhasil diubah menjadi dokter hewan');
        return redirect()->to('/dokterHewan');
    }

    public function update()
    {
        $data = [
            'title' => 'Pawtroli | Veterinary'
        ];
        helper(['form']);
        $model = new DokterHewanModel();

        if ($this->request->getMethod() == 'post') {
            // validation rules
            $rules = [
                'nama_klinik' => 'required',
                'phone' => 'required',
                'address' => 'required',
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                //store user on database
                $model = new DokterHewanModel();

                // // ambil gambar
                // $fileFoto = $this->request->getFile('foto');
                // // apabila tidak ada gambar yang di upload | == 4 maksudnya error tidak ada file yang diupload
                // if ($fileFoto->getError() == 4) {
                //     $namaFoto = 'default.jpg';
                // } else {
                //     //generate nama foto random
                //     $namaFoto = $fileFoto->getRandomName();
                //     // pindahkan file ke folder img
                //     $fileFoto->move('img', $namaFoto);
                // }


                $newData = [
                    'id' => session()->get('id'),
                    'nama_klinik' => $this->request->getPost('nama_klinik'),
                    'phone' => $this->request->getPost('phone'),
                    'address' => $this->request->getPost('address'),
                    // 'foto' => $namaFoto,
                ];
                $model->save($newData);

                session()->setFlashdata('success', 'Successful Updated');
                return redirect()->to('/dokterHewan/detail/' . session()->get('name'));
            }
        }

        $data['dokterHewan'] = $model->where('id', session()->get('id'))->first();
        echo view('dokterHewan/update', $data);
    }
}
