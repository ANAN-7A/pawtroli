<?php

namespace App\Controllers;

use App\Models\DokterModel;

class Dokter extends BaseController
{
    protected $dokterModel;

    public function __construct()
    {
        $this->dokterModel = new DokterModel();
    }

    public function index()
    {
        // kasih logika klo ada isi berarti page ambil isinya klo gk ada page 1
        $currentPage = $this->request->getVar('page_dokter') ? $this->request->getVar('page_dokter') : 1;

        $keyword = $this->request->getVar('keyword');
        if ($keyword) {
            $dokter = $this->dokterModel->search($keyword);
        } else {
            $dokter = $this->dokterModel;
        }

        // $dokter = $this->dokterModel->findAll();

        $data = [
            'title' => 'Pawtroli | Veterinary',
            // 'dokter' => $this->dokterModel->getDokter()
            'dokter' => $dokter->paginate(9, 'dokter'),
            'pager' => $this->dokterModel->pager,
            'currentPage' => $currentPage
        ];

        // $dokterModel = new \App\Models\DokterModel();


        return view('dokter/index', $data);
    }

    public function detail($slug)
    {
        $data = [
            'title' => 'Pawtroli | Veterinary',
            'dokter' => $this->dokterModel->getDokter($slug)
        ];

        // jika dokter tidak ditemukan
        if (empty($data['dokter'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Dokter ' . $slug . ' tidak ditemukan.');
        }

        return view('dokter/detail', $data);
    }

    public function create()
    {
        // dah gk perlu karena dari BaseController dah ada
        // session();
        // ngambil; data validation dari function save dengan session
        $data = [
            'title' => 'Form Tambah Data Dokter',
            'validation' => \Config\Services::validation()
        ];
        return view('dokter/create', $data);
    }

    public function save()
    {
        // validasi input
        if (!$this->validate([
            // 'nama' => 'required|is_unique[dokter.nama]'
            // dibawah dipakai untuk validasi dengan message sendiri
            'nama' => [
                'rules' => 'required|is_unique[dokter.nama]',
                'errors' => [
                    'required' => '{field} dokter harus diisi',
                    'is_unique' => '{field} dokter sudah terdaftar'
                ]
                // validasi lokasi praktek belum ada tapi cara kerjanya sama dengan nama
            ],
            'foto' => [
                'rules' => 'is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]|max_size[foto,1024]',
                'errors' => [
                    'is_image' => 'yang anda pilih bukan gambar',
                    'mime_in' => 'yang anda pilih bukan gambar',
                    'max_size' => 'Ukuran foto terlalu besar'
                ]
            ]
        ])) {
            // dibawah tidak perlu karena data nya sudah dikirim lewat withinput dan validasi nya sudah lewat session
            // $validation = \Config\Services::validation();
            // // dd($validation);
            // // membawa data validation balik ke halaman create
            // return redirect()->to('/dokter/create')->withInput()->with('validation', $validation);
            return redirect()->to('/dokter/create')->withInput();
        }

        // ambil gambar
        $fileFoto = $this->request->getFile('foto');
        // apabila tidak ada gambar yang di upload | == 4 maksudnya error tidak ada file yang diupload
        if ($fileFoto->getError() == 4) {
            $namaFoto = 'default.jpg';
        } else {
            //generate nama foto random
            $namaFoto = $fileFoto->getRandomName();
            // pindahkan file ke folder img
            $fileFoto->move('img', $namaFoto);

            // // nama yang disimpan di DB sama dengan nama foto yang di upload
            // // ambil nama file
            // $namaFoto = $fileFoto->getName();
        }


        //untuk membuat string menjadi kecil semua dan tanpa spasi (for slug)
        $slug = url_title($this->request->getVar('nama'), '-', true);
        $this->dokterModel->save([
            'nama' => $this->request->getVar('nama'),
            'slug' => $slug,
            'lokasi_praktek' => $this->request->getVar('lokasi_praktek'),
            'foto' => $namaFoto
        ]);

        session()->setFlashdata('pesan', 'Data berhasil ditambahkan');

        return redirect()->to('/dokter');
    }

    public function delete($id)
    {
        //cari gambar berdasarkan id
        $dokter = $this->dokterModel->find($id);

        // cek jika file gambarnya default
        if ($dokter['foto'] != 'default.jpg') {
            // hapus gambar
            unlink('img/' . $dokter['foto']);
        }

        $this->dokterModel->delete($id);
        session()->setFlashdata('pesan', 'Data berhasil dihapus');
        return redirect()->to('/dokter');
    }

    public function edit($slug)
    {
        $data = [
            'title' => 'Form Ubah Data Dokter',
            'validation' => \Config\Services::validation(),
            'dokter' => $this->dokterModel->getDokter($slug)
        ];
        return view('dokter/edit', $data);
    }

    public function update($id)
    {
        // cek nama apakah sama dengan yang lama = gk ganti berarti
        // atau nama sama dengan nama lain = berarti gk bisa (is_unique)
        $dokterLama = $this->dokterModel->getDokter($this->request->getVar('slug'));
        if ($dokterLama['nama'] == $this->request->getVar('nama')) {
            $rule_nama = 'required';
        } else {
            $rule_nama = 'required|is_unique[dokter.nama]';
        }

        // validasi input
        if (!$this->validate([
            // 'nama' => 'required|is_unique[dokter.nama]'
            // dibawah dipakai untuk validasi dengan message sendiri
            'nama' => [
                'rules' => $rule_nama,
                'errors' => [
                    'required' => '{field} dokter harus diisi',
                    'is_unique' => '{field} dokter sudah terdaftar'
                ]
                // validasi lokasi praktek belum ada tapi cara kerjanya sama dengan nama
            ],
            'foto' => [
                'rules' => 'is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]|max_size[foto,1024]',
                'errors' => [
                    'is_image' => 'yang anda pilih bukan gambar',
                    'mime_in' => 'yang anda pilih bukan gambar',
                    'max_size' => 'Ukuran foto terlalu besar'
                ]
            ]
        ])) {
            // sudah tidak perlu
            // $validation = \Config\Services::validation();
            // dd($validation);
            // membawa data validation balik ke halaman create
            // return redirect()->to('/dokter/edit/' . $this->request->getVar('slug'))->withInput()->with('validation', $validation);
            return redirect()->to('/dokter/edit/' . $this->request->getVar('slug'))->withInput();
        }

        $fileFoto = $this->request->getFile('foto');

        // cek gambar, apakah tetap gambar lama
        if ($fileFoto->getError() == 4) {
            $namaFoto = $this->request->getVar('fotoLama');
        } else {
            // generate nama file random
            $namaFoto = $fileFoto->getRandomName();
            // pindahkan gambar
            $fileFoto->move('img', $namaFoto);
            // hapus file yang lama
            unlink('img/' . $this->request->getVar('fotoLama'));
        }

        // slug di generate juga difungsi update
        $slug = url_title($this->request->getVar('nama'), '-', true);
        $this->dokterModel->save([
            'id' => $id,
            'nama' => $this->request->getVar('nama'),
            'slug' => $slug,
            'lokasi_praktek' => $this->request->getVar('lokasi_praktek'),
            'foto' => $namaFoto
        ]);

        session()->setFlashdata('pesan', 'Data berhasil diubah');

        return redirect()->to('/dokter');
    }
}
