<?php

namespace App\Controllers;

use App\Models\AdopsiModel;

class Adopsi extends BaseController
{
    protected $adopsiModel;

    public function __construct()
    {
        $this->adopsiModel = new AdopsiModel();
    }

    public function index()
    {
        // kasih logika klo ada isi berarti page ambil isinya klo gk ada page 1
        $currentPage = $this->request->getVar('page_') ? $this->request->getVar('page_adopsi') : 1;

        $keyword = $this->request->getVar('keyword');
        if ($keyword) {
            $adopsi = $this->adopsiModel->search($keyword);
        } else {
            $adopsi = $this->adopsiModel;
        }

        $data = [
            'title' => 'Pawtroli | Free Adoption',
            // 'artikel' => $this->artikelModel->findAll()
            // klo jumlah paginate diubah jangan lupa diganti kalkulasi logika nya
            'adopsi' => $adopsi->paginate(9, 'adopsi'),
            'pager' => $this->adopsiModel->pager,
            'currentPage' => $currentPage
        ];

        return view('adopsi/index', $data);
    }

    public function detail($nama)
    {
        $data = [
            'title' => 'Pawtroli | Free Adoption',
            'adopsi' => $this->adopsiModel->getAdopsi($nama)
        ];

        // jika dokter tidak ditemukan
        if (empty($data['adopsi'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('adopsi ' . $nama . ' tidak ditemukan.');
        }

        return view('adopsi/detail', $data);
    }

    public function create()
    {
        $data = [
            'title' => 'Pawtroli | Free Adoption'
        ];
        helper(['form']);

        if ($this->request->getMethod() == 'post') {
            // validation rules
            $rules = [
                'nama' => [
                    'rules' => 'required|is_unique[adopsi.nama]|alpha',
                    'errors' => [
                        'required' => '{field} harus diisi',
                        'is_unique' => '{field} sudah terdaftar',
                        'alpha' => '{field} harus berisi huruf'
                    ]
                ],
                'pemilik' => 'required',
                'jenis_kelamin' => [
                    'rules' => 'required|in_list[Jantan,Betina]',
                    'errors' => [
                        'required' => '{field} harus diisi',
                        'in_list' => 'Jenis Kelamin hewan harus dipilih (Jantan/Betina)'
                    ]
                ],
                'jenis_hewan' => 'required',
                'ras_hewan' => 'required',
                'umur' => [
                    'rules' => 'required|numeric',
                    'errors' => [
                        'required' => '{field} harus diisi',
                        'numeric' => '{field} harus angka'
                    ]
                ],
                'telepon' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => '{field} harus diisi',
                    ]
                ],
                'alamat' => 'required',
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                //store user on database
                $model = new AdopsiModel();

                // ambil gambar
                $fileFoto = $this->request->getFile('foto');
                // apabila tidak ada gambar yang di upload | == 4 maksudnya error tidak ada file yang diupload
                if ($fileFoto->getError() == 4) {
                    $namaFoto = 'default.jpg';
                } else {
                    //generate nama foto random
                    $namaFoto = $fileFoto->getRandomName();
                    // pindahkan file ke folder img
                    $fileFoto->move('img', $namaFoto);
                }

                $newData = [
                    'nama' => $this->request->getVar('nama'),
                    'pemilik' => $this->request->getVar('pemilik'),
                    'foto' => $namaFoto,
                    'jenis_kelamin' => $this->request->getVar('jenis_kelamin'),
                    'jenis_hewan' => $this->request->getVar('jenis_hewan'),
                    'ras_hewan' => $this->request->getVar('ras_hewan'),
                    'umur' => $this->request->getVar('umur'),
                    'telepon' => $this->request->getVar('telepon'),
                    'alamat' => $this->request->getVar('alamat'),
                    'is_active' => '1',
                ];
                $model->save($newData);
                $session = session();

                $session->setFlashdata('success', 'Adopsi Baru Sukses');
                return redirect()->to('/adopsi');
            }
        }

        echo view('adopsi/create', $data);
    }

    public function nonactive($id)
    {
        //cari gambar berdasarkan nama
        $dokter = $this->adopsiModel->find($id);

        $this->adopsiModel->save([
            'id' => $id,
            'is_active' => '0'
        ]);
        session()->setFlashdata('pesan1', 'Adopsi berhasil dinonaktifkan');
        return redirect()->to('/adopsi');
    }

    public function delete($id)
    {
        //cari gambar berdasarkan id
        $adopsi = $this->adopsiModel->find($id);

        // cek jika file gambarnya default
        if ($adopsi['foto'] != 'default.jpg') {
            // hapus gambar
            unlink('img/' . $adopsi['foto']);
        }

        $this->adopsiModel->delete($id);
        session()->setFlashdata('pesan2', 'Adopsi berhasil dihapus');
        return redirect()->to('/adopsi');
    }
}
