<?php

namespace App\Controllers;

use App\Models\KlinikModel;

class Klinik extends BaseController
{
    protected $klinikModel;

    public function __construct()
    {
        $this->klinikModel = new KlinikModel();
    }

    public function index()
    {
        // kasih logika klo ada isi berarti page ambil isinya klo gk ada page 1
        $currentPage = $this->request->getVar('page_klinik') ? $this->request->getVar('page_klinik') : 1;

        $keyword = $this->request->getVar('keyword');
        if ($keyword) {
            $klinik = $this->klinikModel->search($keyword);
        } else {
            $klinik = $this->klinikModel;
        }

        $data = [
            'title' => 'Pawtroli | Clinic',
            // 'artikel' => $this->artikelModel->findAll()
            // klo jumlah paginate diubah jangan lupa diganti kalkulasi logika nya
            'klinik' => $klinik->paginate(12, 'klinik'),
            'pager' => $this->klinikModel->pager,
            'currentPage' => $currentPage
        ];

        return view('klinik/index', $data);
    }

    public function detail($nama)
    {
        $data = [
            'title' => 'Pawtroli | Clinic',
            'klinik' => $this->klinikModel->getKlinik($nama)
        ];

        // jika dokter tidak ditemukan
        if (empty($data['klinik'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Klinik ' . $nama . ' tidak ditemukan.');
        }

        return view('klinik/detail', $data);
    }

    public function create()
    {
        $data = [
            'title' => 'Pawtroli | Clinic'
        ];
        helper(['form']);

        if ($this->request->getMethod() == 'post') {
            // validation rules
            $rules = [
                'nama' => 'required|is_unique[klinik.nama]',
                'alamat' => 'required',
                'koordinat' => 'required',
                'deskripsi' => 'required',
                'telepon' => 'required',
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                //store user on database
                $model = new klinikModel();

                // ambil gambar
                $fileFoto = $this->request->getFile('foto');
                // apabila tidak ada gambar yang di upload | == 4 maksudnya error tidak ada file yang diupload
                if ($fileFoto->getError() == 4) {
                    $namaFoto = 'default.jpg';
                } else {
                    //generate nama foto random
                    $namaFoto = $fileFoto->getRandomName();
                    // pindahkan file ke folder img
                    $fileFoto->move('img', $namaFoto);
                }

                $newData = [
                    'nama' => $this->request->getVar('nama'),
                    'nama_dokter' => $this->request->getVar('nama_dokter'),
                    'foto' => $namaFoto,
                    'alamat' => $this->request->getVar('alamat'),
                    'koordinat' => $this->request->getVar('koordinat'),
                    'deskripsi' => $this->request->getVar('deskripsi'),
                    'telepon' => $this->request->getVar('telepon'),
                    'tipe' => $this->request->getVar('tipe'),
                ];
                $model->save($newData);
                $session = session();

                $session->setFlashdata('success', 'Tambah Klinik Sukses');
                return redirect()->to('/klinik');
            }
        }

        echo view('klinik/create', $data);
    }
    
    public function delete($id)
    {
        //cari gambar berdasarkan id
        $klinik = $this->klinikModel->find($id);

        // cek jika file gambarnya default
        if ($klinik['foto'] != 'default.jpg') {
            // hapus gambar
            unlink('img/' . $klinik['foto']);
        }

        $this->klinikModel->delete($id);
        session()->setFlashdata('pesan', 'Klinik berhasil dihapus');
        return redirect()->to('/klinik');
    }
    
}
